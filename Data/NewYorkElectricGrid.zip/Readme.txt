1. The file "nysiobuses.csv" contains information about the buses (nodes) of the New York state power grid.  The first column is the "bus number."
2. The file "nyisobranches.csv" indicates for each branch the numbers for the two buses connected by that branch.
